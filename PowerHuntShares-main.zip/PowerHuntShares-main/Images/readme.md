This folder is for image files.
